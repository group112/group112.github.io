#ifndef __EXCEPTION_H__
#define __EXCEPTION_H__

#include <iosfwd>


class Exception {
public:
    Exception(int c, const char *m);

    int code() const { return code_; }
    const char *message() { return message_; }

    Exception operator=(const Exception &) = delete; 

    friend std::ostream &operator<<(std::ostream &o, const Exception &e);

private:
    int  code_;
    char message_[10];
};

#endif
