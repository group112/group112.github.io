$ ulimit -a
...
virtual memory          (kbytes, -v) unlimited
...

$ ulimit -v 8192

$ ulimit -a
...
virtual memory          (kbytes, -v) 8192
...

$ ./pr1
main - start
foo  - start
bar  - start
foo  - some exception
main - memory allocation error
main - finish

