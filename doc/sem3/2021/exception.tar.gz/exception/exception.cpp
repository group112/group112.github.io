#include "exception.h"

#include <iostream>
#include <cstdio>


Exception::Exception(int c, const char *m): code_(c) {
    snprintf(message_, sizeof message_, "%s", m);
}


std::ostream &operator<<(std::ostream &o, const Exception &e) {
    return o << e.code_ << ": " << e.message_;
}

