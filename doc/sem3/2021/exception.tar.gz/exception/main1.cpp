#include <iostream>
#include <cstdio>

//void bar([[maybe_unused]] int i) {
void bar(int i) {
    //(void)i;
    std::cout << "bar  - start" << std::endl;

    switch(i) {
        case 1:
            throw 255;

        case 2:
            throw 1.5;

        case 3:
            //[[maybe_unused]] double *a = new double[1000000];
            [[maybe_unused]] double *a = new (std::nothrow) double[1000000];
            std::cout << "bar  - a: " << a << std::endl;

            break;     
    }

    std::cout << "bar  - finish" << std::endl;
}


void foo(int i) {
    std::cout << "foo  - start" << std::endl;

    try {
        bar(i);
    }
    catch(int e1) {
        std::cout << "foo  - catch(int i): " << e1 << std::endl;
        
    }
    catch(...) {
        std::cout << "foo  - some exception" << std::endl;
        throw;
    }

    std::cout << "foo  - finish" << std::endl;
}


int main() {
    std::cout << "main - start" << std::endl;

    try {
        //foo(1);
        //foo(2);
        foo(3);


    }
    catch(double e1) {
        std::cout << "main - catch(double e1): " << e1 << std::endl;
        
    }
    catch(const std::bad_alloc &) {

        std::cout << "main - memory allocation error" << std::endl;
    }
    catch(...) {
        std::cout << "main - some exception" << std::endl;
    }

    std::cout << "main - finish" << std::endl;
    return 0;
}

