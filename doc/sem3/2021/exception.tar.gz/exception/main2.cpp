#include "exception.h"

#include <iostream>


void foo(int i) {
    std::cout << "foo  - start" << std::endl;

    if(i)
        throw Exception(103, "Some problem!");

    std::cout << "foo  - finish" << std::endl;
}

int main() {
    Exception e1(101, "Oops!"), e2(102, "Big problem!");

    std::cout << e1 << std::endl << e2 << std::endl;

    try {
        //foo(0);
        foo(1);
    }
    catch(const Exception &e3) {
        std::cout << e3 << std::endl;
    }

    return 0;
}

