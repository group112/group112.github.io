#include "exception.h"

#include <iostream>


int main() {
    Exception e1(101, "Oops!"), e2(102, "Big problem!");

    std::cout << e1 << std::endl << e2 << std::endl;


    return 0;
}

