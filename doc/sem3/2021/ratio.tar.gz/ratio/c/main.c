#include <stdio.h>
#include <assert.h>


struct Ratio {
    int p;
    int q;
};


void print(struct Ratio *th, FILE *fo) {
    fprintf(fo, "%d/%d\n", th->p, th->q);
}


int integer(struct Ratio *th) {
    return th->p / th->q;
}


int main(void) {
    struct Ratio x;
    //(void)x;

    x.p = 4;
    x.q = 3;

    print(&x, stdout);

    assert(x.p == 4 && x.q == 3);

    assert(integer(&x) == 2);

    return 0;
}

