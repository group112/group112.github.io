gcc -g -Wall -Wextra -Werror -pedantic -std=c99 main.c -o pr

