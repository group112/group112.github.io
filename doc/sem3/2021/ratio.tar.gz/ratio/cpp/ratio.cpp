#include "ratio.h"


void Ratio::print(FILE *fo) {
    fprintf(fo, "%d/%d\n", p, this->q);
}


