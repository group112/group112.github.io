#include "ratio.h"
#include <cassert>


int main() {
    Ratio x(4, 5);
    Ratio y(6, 5);

    Ratio z = x + y;
    z.print(stdout);

    Ratio &u = x;

    x.print(stdout);
    u.print(stdout);
    u = Ratio(6, 5);
    x.print(stdout);

    const Ratio &v = x;
    v.print(stdout);

    //(v + 2).print(stdout);

    double w = (double)Ratio(2, 3);
    printf("w: %.2f\n", w);


    /*
    Ratio x(4, 5);
    Ratio y;
    Ratio z(7);

    y = x.plus(z);

    x.print(stdout);
    y.print(stdout);
    z.print(stdout);


    //z.q = 0;
    z.integer();

    y = x.operator+(z);
    y.print(stdout);

    y = x + z;
    y.print(stdout);

    y = x + 8; // x.operator+(Ratio(8))
    y.print(stdout);

    y = Ratio(2, 3) + Ratio(1, 3);
    y.print(stdout);

    (Ratio(2, 3) + Ratio(4, 3)).print(stdout);


    y = 8 + x; 
    y.print(stdout);


    //assert(x.p == 4 && x.q == 5);
    assert(x.integer() == 0);
    */

    return 0;
}

