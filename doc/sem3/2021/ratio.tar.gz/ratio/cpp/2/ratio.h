#ifndef _RATIO_H_
#define _RATIO_H_

#include <cstdio>

class Ratio {
public:
    Ratio();      // конструктор по умолчанию
    Ratio(int p); // конструктор преобразования типа
    //explicit Ratio(int p);
    Ratio(int p, int q);
   
    Ratio plus(Ratio r);

    Ratio operator+(const Ratio &r) const;

    explicit operator double() const;

    void print(FILE *fo) const;

    int integer();

    friend Ratio operator+(int i, Ratio r);

private:
    int p_;
    int q_;

};

#endif
