#include "ratio.h"


Ratio::Ratio() { 
    p_ = 0;
    q_ = 1;
}


Ratio::Ratio(int p) {
    puts("Ratio(int)");
    p_ = p;
    q_ = 1;
}


Ratio::Ratio(int p, int q) {
    p_ = p;
    q_ = q;
}


Ratio Ratio::plus(Ratio r) {
    return Ratio(p_ * r.q_ + r.p_ * q_ , q_ * r.q_); 
}


Ratio Ratio::operator+(const Ratio &r) const {
    return Ratio(p_ * r.q_ + r.p_ * q_ , q_ * r.q_); 
}


Ratio::operator double() const {
    return (double)p_ / q_;
}


int Ratio::integer() {
    return p_ / q_;
}


void Ratio::print(FILE *fo) const {
    fprintf(fo, "%d/%d\n", p_, this->q_);
}


/*
Ratio operator+(int i, Ratio r) {
    return r + i; 
}
*/

/*
Ratio operator+(int i, Ratio r) {
    Ratio x(i);
    Ratio y = r + x;
    return y; 
}
*/

/*
Ratio operator+(int i, Ratio r) {
    Ratio x(i);
    Ratio y = r.operator+(x);
    return y; 
}
*/

Ratio operator+(int i, Ratio r) {
    return Ratio(i * r.q_ + r.p_, r.q_);
}

