1)
gcc -g -Wall -Wextra -Werror -pedantic -std=c99 main.c -o pr

2)
g++ -g -Wall -Wextra -Werror -pedantic -std=c++11 main.cpp ratio.cpp -o pr

3)
g++ -g -Wall -Wextra -Werror -pedantic -std=c++11 -c main.cpp 
g++ -g -Wall -Wextra -Werror -pedantic -std=c++11 -c ratio.cpp
g++ main.o ratio.o -o pr

4) 
make

