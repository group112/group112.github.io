#ifndef _RATIO_H_
#define _RATIO_H_

#include <cstdio>

struct Ratio {
    int p;
    int q;

    void print(FILE *fo);

    int integer() {
        return p / q;
    }
};


#endif
