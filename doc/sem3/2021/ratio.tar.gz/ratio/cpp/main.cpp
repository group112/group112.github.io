#include "ratio.h"
#include <cassert>


int main() {
    Ratio x;

    x.p = 4;
    x.q = 5;

    x.print(stdout);

    assert(x.p == 4 && x.q == 5);

    assert(x.integer() == 0);

    return 0;
}

