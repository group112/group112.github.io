#include "segment.h"
#include <iostream>

Segment::Segment(const Ratio &f, const Ratio &l): 
    fst_(f), 
    lst_(l) 
{}


Segment::Segment(int p1, int q1, int p2, int q2):
    fst_(p1, q1), 
    lst_(p2, q2) 
{}

/*
Segment::Segment(int p1, int q1, int p2, int q2) {
    fst_ = Ratio(p1, q1); 
    lst_ = Ratio(p2, q2); 
}
*/


std::ostream &operator<<(std::ostream &o, const Ratio &r) {
    o << r.p_ << "/" << r.q_;
    return o;
}


std::ostream &operator<<(std::ostream &o, const Segment &s) {
    o << "[" << s.fst_ << ", " << s.lst_ << "]";
    return o;
}

