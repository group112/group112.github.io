#ifndef _RATIO_H_
#define _RATIO_H_

#include <iosfwd>

class Ratio {
public:
    Ratio(int p, int q): p_(p), q_(q) {}

    friend std::ostream &operator<<(std::ostream &o, const Ratio &r);

private:
    int p_;
    int q_;
};

#endif
