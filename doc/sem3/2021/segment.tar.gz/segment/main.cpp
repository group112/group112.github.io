#include "segment.h"
#include <iostream>


int main() {
    Segment s(1, 3, 2, 3);
    std::cout << s << std::endl;

    return 0;
}

