#ifndef _SEGMENT_H_
#define _SEGMENT_H_

#include "ratio.h"

class Segment{
public:
    Segment(const Ratio &f, const Ratio &l);
    Segment(int p1, int q1, int p2, int q2);

    friend std::ostream &operator<<(std::ostream &o, const Segment &s);

private:
    Ratio fst_;
    Ratio lst_;
};

#endif
