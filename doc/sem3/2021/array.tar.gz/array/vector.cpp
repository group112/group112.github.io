#include "vector.h"

#include <iostream>
#include <cstring>


Vector::Vector(): size_(0), data_(nullptr) {}


Vector::Vector(const Vector &vec): size_(vec.size_), data_(new double[size_]) {
    for(size_t i = 0; i < size_; ++ i)
        data_[i] = vec.data_[i];
}


Vector::Vector(size_t count, double val): size_(count), data_(nullptr) {
    if(count)
        data_ = new double[count];

    for(size_t i = 0; i < size_; ++ i)
        data_[i] = val;
}


Vector::~Vector() {
    delete[] data_;
}


Vector &Vector::operator=(const Vector &vec) {
    Vector tmp(vec);
    swap(tmp);
    return *this;
}


double &Vector::operator[](size_t i) {
    if(i >= size_) {
        size_t  s = i + 1;
        double *d = new double[s];

        memset(d, 0, s * sizeof(double));

        if(size_)
            memcpy(d, data_, size_ * sizeof(double));

        delete[] data_;

        data_ = d;
        size_ = s;
    }

    return data_[i];
}


const double &Vector::operator[](size_t i) const {
    return data_[i];
}

 
void Vector::swap(Vector &vec) {
    size_t  s = size_;
    double *d = data_;

    size_ = vec.size_;
    data_ = vec.data_;

    vec.size_ = s;
    vec.data_ = d; 
}


size_t Vector::size() const {
    return size_;
}


double *Vector::data() const {
    return data_;
}

 
std::ostream &operator<<(std::ostream &o, const Vector &vec) {
    o << vec.size_ << ":";

    for(size_t i = 0; i < vec.size_; ++ i)
        o << " " << vec.data_[i];

    return o;
}

