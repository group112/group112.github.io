#include "array.h"

#include <iostream>


Array::Array(): size_(0), data_(nullptr) {}


Array::Array(const Array &arr): size_(arr.size_), data_(new double[size_]) {
    for(size_t i = 0; i < size_; ++ i)
        data_[i] = arr.data_[i];
}


Array::Array(size_t count, double val): size_(count), data_(nullptr) {
    if(count)
        data_ = new double[count];

    for(size_t i = 0; i < size_; ++ i)
        data_[i] = val;
}


Array::~Array() {
    delete[] data_;
}


Array &Array::operator=(const Array &arr) {
    Array tmp(arr);
    swap(tmp);
    return *this;
}


double &Array::operator[](size_t i) {
    return data_[i];
}


const double &Array::operator[](size_t i) const {
    return const_cast<Array &>(*this)[i];
}


void Array::swap(Array &arr) {
    size_t  s = size_;
    double *d = data_;

    size_ = arr.size_;
    data_ = arr.data_;

    arr.size_ = s;
    arr.data_ = d; 
}


size_t Array::size() const {
    return size_;
}


double *Array::data() const {
    return data_;
}


std::ostream &operator<<(std::ostream &o, const Array &arr) {
    o << arr.size_ << ":";

    for(size_t i = 0; i < arr.size_; ++ i)
        o << " " << arr.data_[i];

    return o;
}

