#ifndef __VECTOR_H__
#define __VECTOR_H__

#include <iosfwd>


class Vector {
public:
    Vector();
    Vector(const Vector &vec);
    Vector(size_t count, double val);
    ~Vector();

    Vector &operator=(const Vector &vec);

    double &operator[](size_t i);
    double operator[](size_t i) const;

    void swap(Vector &vec);

    size_t size() const;
    double *data() const;

    friend std::ostream &operator<<(std::ostream &o, const Vector &vec);

private:
    size_t  size_;
    double *data_;
};

#endif
