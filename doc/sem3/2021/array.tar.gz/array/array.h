#ifndef __ARRAY_H__
#define __ARRAY_H__

#include <iosfwd>


class Array {
public:
    Array();
    Array(const Array &arr);
    Array(size_t count, double val);
    ~Array();

    Array &operator=(const Array &arr);

    double &operator[](size_t i);
    const double &operator[](size_t i) const;

    void swap(Array &arr);

    size_t size() const;
    double *data() const;

    friend std::ostream &operator<<(std::ostream &o, const Array &arr);

private:
    size_t  size_;
    double *data_;
};

#endif
