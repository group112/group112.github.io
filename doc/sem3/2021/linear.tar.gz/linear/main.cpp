#include "linear.h"

int main() {
    Linear l(2, 1);

    print(stdout, l);

    printf("%.2f\n", l(0.));
    printf("%.2f\n", l(1.));
    printf("%.2f\n", l(2.));

    return 0;
}

