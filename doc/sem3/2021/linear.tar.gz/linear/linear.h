#ifndef _LINEAR_H_
#define _LINEAR_H_

#include <cstdio>

class Linear {
public:
    Linear(double a, double b);

    double operator()(double x) const;

    friend void print(FILE *fo, const Linear &l);

private:
    double a_, b_;
};


#endif
