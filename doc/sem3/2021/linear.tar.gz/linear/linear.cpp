#include "linear.h"

Linear::Linear(double a, double b): a_(a), b_(b) {}

double Linear::operator()(double x) const {
    return a_ * x + b_;
}

void print(FILE *fo, const Linear &l) {
    fprintf(fo, "%.2f/%.2f\n", l.a_, l.b_);
}

