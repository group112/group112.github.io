#include "array.h"

#include <iostream>


void test01() {
    std::cout << "Test 01." << std::endl << std::endl;

    Array a(10, 1.5), b(5, 0.7);

    std::cout << "a " << a << std::endl << "b " << b << std::endl;

    a.swap(b);

    std::cout << "a " << a << std::endl << "b " << b << std::endl;
}


void test02() {
    std::cout << "Test 02." << std::endl << std::endl;

    Array a, b(5, 0.7);

    std::cout << "a " << a << std::endl << "b " << b << std::endl;

    a = b;

    std::cout << "a " << a << std::endl << "b " << b << std::endl;
}


void test03() {
    std::cout << "Test 03." << std::endl << std::endl;

    Array a(10, 1.);

    std::cout << "a " << a << std::endl;
   
    for(size_t i = 1; i < a.size(); ++ i)
        a[i] += a[i - 1];       
   
    std::cout << "a " << a << std::endl;
}


int main() {
    //test01();
    //test02();
    test03();

    return 0;
}

