#include "cvector.h"

#include <iostream>
#include <cstring>


Vector::Cursor::Cursor(Vector *v, size_t i): v_(v), i_(i) {}


Vector::Cursor::operator double() {
    if(i_ >= v_->size_)
        return 0.;
    else 
        return v_->data_[i_];
}


double Vector::Cursor::operator=(double x) {
    if(i_ >= v_->size_) {
        size_t  s = i_ + 1;
        double *d = new double[s];

        memset(d, 0, s * sizeof(double));

        if(v_->size_)
            memcpy(d, v_->data_, v_->size_ * sizeof(double));

        delete[] v_->data_;

        v_->data_ = d;
        v_->size_ = s;
    }

    v_->data_[i_] = x;

    return v_->data_[i_];
}


Vector::Vector(): size_(0), data_(nullptr) {}


Vector::Vector(const Vector &vec): size_(vec.size_), data_(new double[size_]) {
    for(size_t i = 0; i < size_; ++ i)
        data_[i] = vec.data_[i];
}


Vector::Vector(size_t count, double val): size_(count), data_(nullptr) {
    if(count)
        data_ = new double[count];

    for(size_t i = 0; i < size_; ++ i)
        data_[i] = val;
}


Vector::~Vector() {
    delete[] data_;
}


Vector &Vector::operator=(const Vector &vec) {
    Vector tmp(vec);
    swap(tmp);
    return *this;
}


Vector::Cursor Vector::operator[](size_t i) {
    return Cursor(this, i);
}


double Vector::operator[](size_t i) const {
    if(i >= size_)
        return 0.;
    else 
        return data_[i];
}

 
void Vector::swap(Vector &vec) {
    size_t  s = size_;
    double *d = data_;

    size_ = vec.size_;
    data_ = vec.data_;

    vec.size_ = s;
    vec.data_ = d; 
}


size_t Vector::size() const {
    return size_;
}


double *Vector::data() const {
    return data_;
}

 
std::ostream &operator<<(std::ostream &o, const Vector &vec) {
    o << vec.size_ << ":";

    for(size_t i = 0; i < vec.size_; ++ i)
        o << " " << vec.data_[i];

    return o;
}

