#include "cvector.h"

#include <iostream>


void test01() {
    std::cout << "Test 01." << std::endl << std::endl;

    Vector v(5, 1.);

    std::cout << "v " << v << std::endl;

    for(size_t i = 10; i < 16; ++ i)
        v[i] = i;

    std::cout << "v " << v << std::endl;
}


void test02() {
    std::cout << "Test 02." << std::endl << std::endl;

    Vector v;

    for(size_t i = 0; i < 5; ++ i) {
        v[i] = i;

        std::cout << v << std::endl;
    }
}


void test03() {
    std::cout << "Test 03." << std::endl << std::endl;

    Vector v(5, 1.);

    for(size_t i = 0; i < 10; ++ i)
        std::cout << v[i] << std::endl;
}


int main() {
    test01();
    test02();
    test03();

    return 0;
}

