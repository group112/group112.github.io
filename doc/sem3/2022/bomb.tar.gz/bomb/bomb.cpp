#include <iostream>
#include "bomb.h"

int getNum(); 

int getNum() {
    static int num;
    num ++;
    return num;
}


Bomb::Bomb(): num_(getNum()) {
    if(num_ > 5)
        throw 1;
}

std::ostream &operator<<(std::ostream &os, const Bomb &b) {
    return os << "Bomb: " << b.num_ << std::endl;
}

