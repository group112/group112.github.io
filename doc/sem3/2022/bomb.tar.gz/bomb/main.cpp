#include <iostream>
#include "bomb.h"

int main() {
    try {
        for(int i = 0; i < 10; i ++)
            std::cout << Bomb();
    }
    catch(...) {
        std::cout << "Bang ..." << std::endl;
    }

    return 0;
}

