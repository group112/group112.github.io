#ifndef __BOMB_H__
#define __BOMB_H__

#include <iosfwd>

class Bomb {
public:
    Bomb();

    friend std::ostream &operator<<(std::ostream &os, const Bomb &b);

private:    
    int num_;
};

#endif
