#include <iostream>
#include <functional>


class H {
    public:
    int foo(int x) {
        return x + 1;
    }
};



void proc2(std::function<int(int)> p) {
    std::cout << p(1) << std::endl << p(2) << std::endl << p(3) << std::endl;
}

int main() {

    H h;
    proc2([&h](int x) -> int { return h.foo(x); });


    return 0;
}

