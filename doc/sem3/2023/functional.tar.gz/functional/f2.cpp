#include <iostream>
#include <functional>


class G {
    public:
    int operator()(int x) {
        return x * x * x;
    }
};


int f(int x) {
    return x * x;
}


void proc2(std::function<int(int)> p) {
    std::cout << p(1) << std::endl << p(2) << std::endl << p(3) << std::endl;
}

int main() {
    proc2(f);

    std::cout << "----" << std::endl;

    G g;
    proc2(g);

    std::cout << "----" << std::endl;

    proc2( [](int x) -> int { return x + 1; } );

    std::cout << "----" << std::endl;

    int y = 10;

    proc2( [y](int x) -> int { return x + y; } );

    std::cout << "y: " << y << std::endl;

    std::cout << "----" << std::endl;

    proc2( [&y](int x) -> int { y ++; return x + y; } );

    std::cout << "y: " << y << std::endl;

    return 0;
}

