#include <iostream>


int f(int x) {
    return x * x;
}


void proc1(int (*p)(int)) {
    std::cout << p(1) << std::endl << p(2) << std::endl << p(3) << std::endl;
}

int main() {
    proc1(f);
    return 0;
}

