#include "conn.h"

static const char *prefix = "Echo: ";

void readConn(conn_t *c) {
    uint32_t h;
    ssize_t  s;
    char    *p;

    if(!canRead(c)) return;

    s = read(c->fd, c->ibuf + c->icur, c->iall - c->icur);

    if(s > 0)
        c->icur += s;
    else
        if(!s)
            goto stop;
        else
            if(s == -1 && errno != EAGAIN && errno != EWOULDBLOCK) {
                fprintf(stderr, "%4d - Read error.\n", c->fd);
                goto stop;
            }

    if(c->iall == c->icur) {
        if(c->iall == sizeof h) {
            memcpy(&h, c->ibuf, sizeof h);
            c->iall += h; 

            if(c->iall + strlen(prefix) > BUFLEN) {
                fprintf(stderr, "%4d - Big message error.\n", c->fd);
                goto stop;
            } 
        }
        else {
            h       = strlen(prefix) + c->iall - sizeof h;
            c->oall = h + sizeof h;

            p       = c->obuf;
            memcpy(p, &h, sizeof h);

            p      += sizeof h;
            memcpy(p, prefix, strlen(prefix));

            p      += strlen(prefix);
            memcpy(p, c->ibuf + sizeof h, c->iall - sizeof h);
        }
    }

    return;

stop:
    printf("%4d - Close.\n", c->fd);

    if(shutdown(c->fd, 2) == -1)
        fprintf(stderr, "%4d - Shutdown error.\n", c->fd);

    if(close(c->fd))
        fprintf(stderr, "%4d - Close error.\n", c->fd);

    c->actv = 0;
}

void writeConn(conn_t *c) {
    ssize_t  s;

    if(!canWrite(c)) return;

    s = write(c->fd, c->obuf + c->ocur, c->oall - c->ocur);

    if(s > 0)
        c->ocur += s;
    else
        if(!s)
            goto stop;
        else
            if(s == -1 && errno != EAGAIN && errno != EWOULDBLOCK) {
                fprintf(stderr, "%4d - Write error.\n", c->fd);
                goto stop;
            }

    if(c->oall == c->ocur) {
        c->icur = 0;
        c->iall = 4;
        c->ocur = 0;
        c->oall = 0;
    }

    return;

stop:
    printf("%4d - Close.\n", c->fd);

    if(shutdown(c->fd, 2) == -1)
        fprintf(stderr, "%4d - Shutdown error.\n", c->fd);

    if(close(c->fd))
        fprintf(stderr, "%4d - Close error.\n", c->fd);

    c->actv = 0;
}

static void printConn(int fd, struct sockaddr_in *addr);

void newConn(int ld, conn_t *cs, size_t ncs) {
    struct sockaddr_in addr;
    socklen_t          addrlen;
    int                fd;
    int                fl;

    memset(&addr, 0, sizeof addr);
    addrlen = sizeof addr;

    fd = accept(ld, (struct sockaddr *)&addr, &addrlen);
    if(fd == -1) {
        if(fd == -1 && errno != EAGAIN && errno != EWOULDBLOCK)
            fprintf(stderr, "     - Accept error.\n");
        return;
    }

    printConn(fd, &addr);

    if((fl = fcntl(fd, F_GETFL)) == -1) {
        fprintf(stderr, "%4d - Fcntl (F_GETFL) error.\n", fd);
        goto stop;
    }

    if(fcntl(fd, F_SETFL, fl | O_NONBLOCK) == -1) {
        fprintf(stderr, "%4d - Fcntl (F_SETFL) error.\n", fd);
        goto stop;
    }

    if((size_t)fd >= ncs) {
        fprintf(stderr, "%4d - Storage limit error.\n", fd);
        goto stop;
    }

    cs[fd].fd   = fd;
    cs[fd].actv = 1;
    cs[fd].icur = 0;
    cs[fd].iall = 4;
    cs[fd].ocur = 0;
    cs[fd].oall = 0;

    return;

stop:
    printf("%4d - Close.\n", fd);

    if(shutdown(fd, 2) == -1)
        fprintf(stderr, "%4d - Shutdown error.\n", fd);

    if(close(fd))
        fprintf(stderr, "%4d - Close error.\n", fd);
}

static void printConn(int fd, struct sockaddr_in *addr) {
    char ip[INET_ADDRSTRLEN];
    inet_ntop(AF_INET, &addr->sin_addr, ip, sizeof ip);
    printf("%4d -New (%s %d).\n", fd, ip, addr->sin_port);
}

int toUInt16(const char *str, uint16_t *p) {
    long  l;
    char *e;

    errno = 0;
    l = strtol(str, &e, 10);

    if(!errno && *e == '\0' && 0 <= l && l <= 65535) {
        *p = (uint16_t)l;
        return 0;
    }
    else
        return -1;
}

