#ifndef __CONN_H__
#define __CONN_H__

#include <arpa/inet.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <unistd.h>
#include <fcntl.h>
#include <poll.h>

#include <inttypes.h>
#include <signal.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <errno.h>

#define BUFLEN 1024

typedef struct {
    int    fd,
           actv;
    size_t icur,
           iall,
           ocur,
           oall;
    char   ibuf[BUFLEN],
           obuf[BUFLEN];
} conn_t;

#define canRead(c)  ((c)->actv && (c)->iall > (c)->icur)
#define canWrite(c) ((c)->actv && (c)->oall > (c)->ocur)

void readConn(conn_t *c);
void writeConn(conn_t *c);
void newConn(int ld, conn_t *cs, size_t ncs);

int toUInt16(const char *str, uint16_t *p);

#endif
