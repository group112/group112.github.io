#include "logic.hpp"

Logic::Logic(): s_(RE_PREFIX) {}

Logic::~Logic() {}

bool Logic::isRe() const {
    return s_ == RE_PREFIX || s_ == RE_TEXT;
}

bool Logic::isWr() const {
    return !isRe();
}

void *Logic::getReBuf(size_t *l) {
    if(s_ == RE_PREFIX) {
        *l = sizeof h_;
        return &h_;
    }
    else { // s_ == RE_TEXT
        *l = h_;
        return &t_[0];
    }
}

const void *Logic::getWrBuf(size_t *l) {
    if(s_ == WR_LEN1 || s_ == WR_LEN2) {
        *l = sizeof h_;
        return &h_;
    }
    else
        if(s_ == WR_ARR1) {
            *l = h_ * sizeof(double);
            return &a1_[0];
        }
        else
            if(s_ == WR_ARR2) {
                *l = h_;
                return &a2_[0];
            }
            else { // s_ == WR_ERROR || s_ == WR_SUCCESS
                *l = 1;
                return &e_;
            }
}

void Logic::next() {
    switch(s_) {
        case RE_PREFIX:
            t_.resize(h_);
            s_ = RE_TEXT;
            break;

        case RE_TEXT:
            if(fromText()) {
                e_ = 0;
                s_ = WR_SUCCESS;
            }
            else {
                e_ = 1;
                s_ = WR_ERROR;
            }
            break;

        case WR_ERROR:
            s_ = RE_PREFIX;
            break;

        case WR_SUCCESS:
            s_ = WR_LEN1;
            break;

        case WR_LEN1:
            s_ = WR_ARR1;
            break;

        case WR_ARR1:
            toSign();
            s_ = WR_LEN2;
            break;

        case WR_LEN2:
            s_ = WR_ARR2;
            break;

        case WR_ARR2:
            s_ = RE_PREFIX;
            break;

        default:
            ;
    }
}

bool Logic::fromText() {
    uint32_t i, n;
    double   x;
    int      p;

    a1_.clear();

    for(i = 0, n = 0; i < h_;) {
        if(t_[i] == ' ' || t_[i] == '\t' || t_[i] == '\n' || t_[i] == '\0') {
            i ++;
            continue;
        }

        if(sscanf(&t_[i], "%lf%n", &x, &p) == 1) {
            a1_.push_back(x);
            n ++;
            i += p;
        }
        else
            return false;
    }

    if(!n)
        return false;

    h_ = n;

    return true;
}

void Logic::toSign() {
    a2_.clear();
   
    uint32_t i;
    for(i = 0; i < h_; i ++) {
        int8_t s = (a1_[i] > 0.) ? 1 : (a1_[i] < 0.) ? -1 : 0;
        a2_.push_back(s);
    }
}

