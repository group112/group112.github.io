#include "conn.h"

#define NCS 100
static conn_t        cs[NCS];
static struct pollfd ps[NCS + 1];

static int signalIgnoring(void);
static void loop(int ld, struct pollfd *ps, conn_t *cs, size_t ncs);

int main(void) {
    uint16_t           port = 8000;
    struct sockaddr_in addr;
    int                ld;
    int                on;
    int                st   = 0;
    int                fl;

    if(signalIgnoring() != 0)
        return -1;

    addr.sin_family      = AF_INET;
    addr.sin_port        = htons(port);
    addr.sin_addr.s_addr = INADDR_ANY;

    ld = socket(AF_INET, SOCK_STREAM, 0);
    if(ld == -1) {
        fprintf(stderr, "     - Socket error.\n");
        return -1;
    }

    on = 1;
    if(setsockopt(ld, SOL_SOCKET, SO_REUSEADDR, &on, sizeof on) == -1) {
        fprintf(stderr, "%4d - Setsockopt error.\n", ld);
        st = -1;
        goto stop;
    }

    if((fl = fcntl(ld, F_GETFL)) == -1) {
        fprintf(stderr, "%4d - Fcntl (F_GETFL) error.\n", ld);
        st = -1;
        goto stop;
    }

    if(fcntl(ld, F_SETFL, fl | O_NONBLOCK) == -1) {
        fprintf(stderr, "%4d - Fcntl (F_SETFL) error.\n", ld);
        st = -1;
        goto stop;
    }

    if(bind(ld, (struct sockaddr *)&addr, sizeof addr) == -1) {
        fprintf(stderr, "%4d - Bind error.\n", ld);
        st = -1;
        goto stop;
    }

    if(listen(ld, 5) == -1) {
        fprintf(stderr, "%4d - Listen error.\n", ld);
        st = -1;
        goto stop;
    }

    loop(ld, ps, cs, NCS);

stop:
    if(close(ld)) {
        fprintf(stderr, "%4d - Close error.\n", ld);
        st = -1;
    }

    puts("Done.");
    
    return st;
}

static void handler(int signo);

static int signalIgnoring(void) {
    struct sigaction act;
    act.sa_handler = handler;
    act.sa_flags   = 0;
    sigemptyset(&act.sa_mask);

    if(sigaction(SIGINT, &act, 0) == -1) {
        fprintf(stderr, "     - Sigaction(SIGINT) error.\n");
        return -1;
    }

    if(sigaction(SIGPIPE, &act, 0) == -1) {
        fprintf(stderr, "     - Sigaction(SIGPIPE) error.\n");
        return -1;
    }

    return 0;
}

static int quit;

static void handler(int signo) {
    if(signo == SIGINT) 
        quit = 1;
}

static void loop(int ld, struct pollfd *ps, conn_t *cs, size_t ncs) {
    nfds_t nps;    
    size_t i;
    short  e;

    ps[0].fd = ld;
    ps[0].events = POLLIN;

    while(!quit) {
        for(nps = 1, i = 0; i < ncs; i ++) 
            if(cs[i].actv) {
                e = 0;
                
                if(canRead(&cs[i]))
                    e = POLLIN;

                if(canWrite(&cs[i]))
                    e = e ? e | POLLOUT : POLLOUT;

                if(e) { 
                    ps[nps].fd     = cs[i].fd;
                    ps[nps].events = e;
                    nps ++;
                }
            }

        switch(poll(ps, nps, 1 * 1000)) {
            case 0:
                puts("Nothing");
                break;

            case -1:
                if(errno != EINTR)
                    fprintf(stderr, "     - Poll error.\n"); 
                break;

            default:
                if(ps[0].revents & POLLIN) 
                    newConn(ld, cs, ncs);

                for(i = 1; i < nps; i ++) {
                    if(ps[i].revents & POLLIN)
                        readConn(&cs[ps[i].fd]);

                    if(ps[i].revents & POLLOUT)
                        writeConn(&cs[ps[i].fd]);
                }
        }
    }
}

