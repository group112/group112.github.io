#include <arpa/inet.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <unistd.h>

#include <signal.h>
#include <string.h>
#include <stdio.h>

static void repl(int fd);
static int writeRead(int fd, const char *txt);
static int signalIgnoring(void);

int main(void) {
    const char        *host = "127.0.0.1";
    uint16_t           port = 8000;
    struct sockaddr_in addr;
    int                fd;

    if(signalIgnoring() != 0)
        return -1;
    
    addr.sin_family = AF_INET;
    addr.sin_port   = htons(port);
    if(inet_pton(AF_INET, host, &addr.sin_addr) < 1) {
        fprintf(stderr, "     - Host error.\n");
        return -1;
    }

    fd = socket(AF_INET, SOCK_STREAM, 0);
    if(fd == -1) {
        fprintf(stderr, "     - Socket error.\n");
        return -1;
    }

    if(connect(fd, (struct sockaddr *)&addr, sizeof addr) == -1) {
        fprintf(stderr, "%4d - Connect error.\n", fd);
        if(close(fd))
            fprintf(stderr, "%4d - Close error.\n", fd);
        return -1;
    }

    repl(fd);

    if(shutdown(fd, 2) == -1) {
        fprintf(stderr, "%4d - Shutdown error.\n", fd);
        if(close(fd))
            fprintf(stderr, "%4d - Close error.\n", fd);
        return -1;
    }

    if(close(fd)) {
        fprintf(stderr, "%4d - Close error.\n", fd);
        return -1;
    }

    return 0;
}

static void handler(int signo);

static int signalIgnoring(void) {
    struct sigaction act;
    act.sa_handler = handler;
    act.sa_flags   = 0;
    sigemptyset(&act.sa_mask);

    if(sigaction(SIGPIPE, &act, 0) == -1) {
        fprintf(stderr, "     - Sigaction(SIGPIPE) error.\n");
        return -1;
    }

    return 0;
}

static void handler(int signo) {
    (void)signo;
}

#define BUFLEN 1024

static void repl(int fd) {
    char buf[BUFLEN];
    for(;;) {
        printf("> ");
        if(!fgets(buf, sizeof buf, stdin))
            return;
        if(writeRead(fd, buf) == -1)
            return;
    }
}

static int writeRead(int fd, const char *txt) {
    uint32_t len;
    char     buf[BUFLEN]; 

    len = strlen(txt) + 1;

    if(write(fd, &len, sizeof len) != sizeof len) {
        fprintf(stderr, "%4d - Write(length) error.\n", fd);
        return -1;
    }

    if(write(fd, txt, len) != (ssize_t)len) {
        fprintf(stderr, "%4d - Write(text) error.\n", fd);
        return -1;
    }

    if(read(fd, &len, sizeof len) != sizeof len) {
        fprintf(stderr, "%4d - Read(length) error.\n", fd);
        return -1;
    }

    if(len > sizeof buf) {
        fprintf(stderr, "%4d - Big message error.\n", fd);
        return -1;
    }

    if(read(fd, buf, len) != (ssize_t)len) {
        fprintf(stderr, "%4d - Read(text) error.\n", fd);
        return -1;
    }

    puts(buf);

    return 0;
}

