#include "logic.hpp"

Logic::Logic(): s_(RE_PREFIX) {
    const char *prefix = "Echo: ";

    p_ = strlen(prefix);

    t_.resize(p_, 0);
    memcpy(&t_[0], prefix, p_);
}

Logic::~Logic() {}

bool Logic::isRe() const {
    return s_ == RE_PREFIX || s_ == RE_TEXT;
}

bool Logic::isWr() const {
    return s_ == WR_PREFIX || s_ == WR_TEXT;
}


void *Logic::getReBuf(size_t *l) {
    if(s_ == RE_PREFIX) {
        *l = sizeof h_;
        return &h_;
    }
    else { // RE_TEXT

        *l = h_;
        return &t_[0] + p_;
    }
}

const void *Logic::getWrBuf(size_t *l) {
    if(s_ == WR_PREFIX) {
        *l = sizeof h_;
        return &h_;
    }
    else { // WR_TEXT
        *l = h_;
        return &t_[0];
    }
}

void Logic::next() {
    if(s_ == RE_PREFIX) {
        t_.resize(p_ + h_, 0);
        s_ = RE_TEXT;
    }
    else
        if(s_ == RE_TEXT) {
            h_ += p_;
            s_ = WR_PREFIX;
        }
        else
            if(s_ == WR_PREFIX) {
                s_ = WR_TEXT;
            }
            else { // s_ == WR_TEXT
                s_ = RE_PREFIX;
            }
}

