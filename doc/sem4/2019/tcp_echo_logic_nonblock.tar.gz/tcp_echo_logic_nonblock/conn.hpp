#ifndef __CONN_HPP__
#define __CONN_HPP__

#include "logic.hpp"

class Conn {
public:
    Conn(int fd);
   ~Conn();

    bool canRcv() const;
    bool canSnd() const;
    bool isActv() const;

    void rcv();
    void snd();

private:
    int    fd_;
    bool   actv_;
    size_t icur_,
           ocur_; 
    Logic  logic_;


    void close_();
};

class ConnDb {
public:
    ConnDb(int ld, size_t nc);
   ~ConnDb();

    void perform();

private:
    int                 ld_;
    size_t              nc_;
    std::vector<Conn *> cs_;
    std::vector<pollfd> ps_;

    void accept_();
};


#endif
