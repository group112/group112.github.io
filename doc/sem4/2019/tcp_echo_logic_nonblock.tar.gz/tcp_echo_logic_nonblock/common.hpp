#ifndef __COMMON_HPP__
#define __COMMON_HPP__

#include <arpa/inet.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <unistd.h>
#include <fcntl.h>
#include <poll.h>

#include <cinttypes>
#include <cstdlib>
#include <cstring>
#include <cstdio>
#include <csignal>
#include <cerrno>

#include <vector>

int toUInt16(const char *str, uint16_t *p);

#endif
