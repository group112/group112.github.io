#ifndef __LOGIC_HPP__
#define __LOGIC_HPP__

#include "common.hpp"

enum State { RE_PREFIX, RE_TEXT, WR_PREFIX, WR_TEXT };

class Logic {
public:
    Logic();
   ~Logic();

    bool isRe() const;
    bool isWr() const;

    void *getReBuf(size_t *l);
    const void *getWrBuf(size_t *l);

    void next();

private:
    State             s_;
    uint32_t          h_,
                      p_;
    std::vector<char> t_;
};

#endif
